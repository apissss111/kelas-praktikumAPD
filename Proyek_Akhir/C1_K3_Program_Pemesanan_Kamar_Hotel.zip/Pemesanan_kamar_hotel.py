import csv
import os
from prettytable import PrettyTable
import pwinput

# Nama file CSV untuk data kamar dan akun
csv_file = 'kamar.csv'
akun_file = 'akun.csv'

# Akun admin khusus
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

# Fungsi untuk memastikan file CSV ada
def initialize_csv():
    if not os.path.exists(csv_file):
        with open(csv_file, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['nomor_kamar', 'deskripsi_fasilitas', 'tipe_kamar', 'harga', 'disabled'])

# Fungsi untuk memastikan file akun CSV ada
def initialize_akun_csv():
    if not os.path.exists(akun_file):
        with open(akun_file, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['username', 'password', 'role'])

# Fungsi untuk membaca data akun dari CSV
def baca_akun():
    akun = []
    try:
        with open(akun_file, 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header
            for row in reader:
                akun.append(row)
    except FileNotFoundError:
        print("File CSV tidak ditemukan. Pastikan file ada atau jalankan 'initialize_akun_csv' untuk membuat file.")
    return akun

# Fungsi untuk membaca data kamar dari CSV
def baca_kamar():
    kamar = []
    try:
        with open(csv_file, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                kamar.append(row)
    except FileNotFoundError:
        print("File CSV kamar tidak ditemukan. Pastikan file ada atau jalankan 'initialize_csv' untuk membuat file.")
    return kamar

# Fungsi untuk menulis data akun ke CSV
def tulis_akun(akun):
    try:
        with open(akun_file, 'w', newline='') as file:
            fieldnames = ['username', 'password', 'role']
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(akun)
    except Exception as e:
        print("Error saat menulis file CSV akun:", e)

# Fungsi untuk menulis data kamar ke CSV
def tulis_kamar(kamar):
    try:
        with open(csv_file, 'w', newline='') as file:
            fieldnames = ['nomor_kamar', 'deskripsi_fasilitas', 'tipe_kamar', 'harga', 'disabled']
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(kamar)
    except Exception as e:
        print("Error saat menulis file CSV kamar:", e)

# Fungsi untuk membuat akun baru dengan pengecekan duplikasi username
def buat_akun():
    username = input("Masukkan username baru: ")
    
    # Membaca semua username yang ada di akun.csv
    akun = baca_akun()
    usernames = [row[0] for row in akun]

    # Periksa apakah username sudah ada (termasuk admin)
    if username == ADMIN_USERNAME:
        print("Username sudah digunakan untuk admin. Silakan pilih username lain.")
        return
    if username in usernames:
        print("Username sudah digunakan. Silakan pilih username lain.")
        return

    # Jika username tersedia, lanjutkan membuat akun baru
    password = pwinput.pwinput("Masukkan password baru: ")  # Menggunakan pwinput
    role = "user"  # Role default untuk akun baru
    with open(akun_file, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password, role])
    print("Akun berhasil dibuat!")

# Fungsi untuk login dengan error handling jika password salah (3 percobaan)
def login():
    attempts = 3  # Maksimum percobaan login
    while attempts > 0:
        username = input("Username: ")
        password = pwinput.pwinput("Password: ")  # Menggunakan pwinput untuk password

        # Login sebagai admin
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            print("Login berhasil! Selamat datang, Admin.")
            menu_admin()
            return

        # Login sebagai user
        akun = baca_akun()
        for row in akun:
            if row[0] == username and row[1] == password and row[2] == "user":
                print(f"Login berhasil! Selamat datang, {username}.")
                menu_user()  # Menu untuk user yang sudah login
                return

        attempts -= 1
        if attempts > 0:
            print(f"Username atau password salah. Percobaan {3 - attempts} dari 3.")
        else:
            print("Login gagal. Percobaan login habis.")

# Fungsi untuk menu Admin
def menu_admin():
    while True:
        print("\n=== Menu Admin ===")
        print("1. Tambah Kamar")
        print("2. Lihat Kamar")
        print("3. Ubah Kamar")
        print("4. Hapus Kamar")
        print("0. Keluar")
        pilihan = input("Pilih menu: ")
        
        if pilihan == '1':
            nomor_kamar = input("Nomor Kamar: ")
            deskripsi_fasilitas = input("Deskripsi Fasilitas: ")
            tipe_kamar = input("Tipe Kamar: ")
            harga = input("Harga: ")
            tambah_kamar(nomor_kamar, deskripsi_fasilitas, tipe_kamar, harga)
        elif pilihan == '2':
            print("\n=== Pilih Opsi ===")
            print("1. Lihat Semua Kamar")
            print("2. Lihat Kamar Terbooking")
            sub_pilihan = input("Pilih opsi: ")
            if sub_pilihan == '1':
                lihat_kamar()
            elif sub_pilihan == '2':
                lihat_kamar_terbooking()
            else:
                print("Pilihan tidak valid.")
        elif pilihan == '3':
            nomor_kamar = input("Nomor Kamar yang ingin diubah: ")
            ubah_detail_kamar(nomor_kamar)
        elif pilihan == '4':
            nomor_kamar = input("Nomor Kamar yang ingin dihapus: ")
            hapus_kamar(nomor_kamar)
        elif pilihan == '0':
            break
        else:
            print("Pilihan tidak valid.")

# Fungsi untuk menu User
def menu_user():
    while True:
        print("\n=== Menu User ===")
        print("1. Lihat Kamar Tersedia")
        print("2. Booking Kamar")
        print("0. Keluar")
        pilihan = input("Pilih menu: ")
        
        if pilihan == '1':
            lihat_kamar_tersedia()
        elif pilihan == '2':
            nomor_kamar = input("Nomor Kamar yang ingin dipesan: ")
            booking_kamar_user(nomor_kamar)
        elif pilihan == '0':
            break
        else:
            print("Pilihan tidak valid.")

# Fungsi untuk melihat kamar yang tersedia (tidak terbooking)
def lihat_kamar_tersedia():
    kamar = baca_kamar()
    tersedia = [k for k in kamar if k['disabled'] == 'enable']
    if tersedia:
        table = PrettyTable()
        table.field_names = ["Nomor Kamar", "Deskripsi", "Tipe Kamar", "Harga"]
        for k in tersedia:
            table.add_row([k['nomor_kamar'], k['deskripsi_fasilitas'], k['tipe_kamar'], k['harga']])
        print(table)
    else:
        print("Tidak ada kamar yang tersedia.")

# Fungsi untuk booking kamar user
def booking_kamar_user(nomor_kamar):
    kamar = baca_kamar()
    kamar_ditemukan = False
    for k in kamar:
        if k['nomor_kamar'] == nomor_kamar:
            if k['disabled'] == 'disable':
                print(f"Kamar {nomor_kamar} sudah terbooking.")
            else:
                k['disabled'] = 'disable'  # Tandai sebagai terbooking
                kamar_ditemukan = True
                print(f"Kamar {nomor_kamar} berhasil dipesan!")
            break
    if not kamar_ditemukan:
        print("Mohon maaf kamar tidak tersedia.")
    tulis_kamar(kamar)
    
    # Fungsi untuk melihat semua kamar (termasuk yang tersedia dan terbooking)
def lihat_kamar():
    kamar = baca_kamar()
    if kamar:
        table = PrettyTable()
        table.field_names = ["Nomor Kamar", "Deskripsi", "Tipe Kamar", "Harga", "Status"]
        for k in kamar:
            status = "Tersedia" if k['disabled'] == 'enable' else "Terbooking"
            table.add_row([k['nomor_kamar'], k['deskripsi_fasilitas'], k['tipe_kamar'], k['harga'], status])
        print(table)
    else:
        print("Tidak ada kamar yang tersedia.")

# Fungsi untuk melihat kamar yang terbooking
def lihat_kamar_terbooking():
    kamar = baca_kamar()
    terbooking = [k for k in kamar if k['disabled'] == 'disable']
    if terbooking:
        table = PrettyTable()
        table.field_names = ["Nomor Kamar", "Deskripsi", "Tipe Kamar", "Harga"]
        for k in terbooking:
            table.add_row([k['nomor_kamar'], k['deskripsi_fasilitas'], k['tipe_kamar'], k['harga']])
        print(table)
    else:
        print("Belum ada kamar yang terbooking.")

# Fungsi untuk mengubah detail kamar
def ubah_detail_kamar(nomor_kamar):
    kamar = baca_kamar()
    kamar_ditemukan = False
    for k in kamar:
        if k['nomor_kamar'] == nomor_kamar:
            k['deskripsi_fasilitas'] = input(f"Deskripsi Fasilitas ({k['deskripsi_fasilitas']}): ") or k['deskripsi_fasilitas']
            k['tipe_kamar'] = input(f"Tipe Kamar ({k['tipe_kamar']}): ") or k['tipe_kamar']
            k['harga'] = input(f"Harga ({k['harga']}): ") or k['harga']
            kamar_ditemukan = True
            print("Kamar berhasil diubah.")
            break
    if not kamar_ditemukan:
        print("Kamar tidak ditemukan.")
    tulis_kamar(kamar)

# Fungsi untuk menambah kamar baru
def tambah_kamar(nomor_kamar, deskripsi_fasilitas, tipe_kamar, harga):
    kamar = baca_kamar()
    kamar_baru = {
        'nomor_kamar': nomor_kamar,
        'deskripsi_fasilitas': deskripsi_fasilitas,
        'tipe_kamar': tipe_kamar,
        'harga': harga,
        'disabled': 'enable'
    }
    kamar.append(kamar_baru)
    tulis_kamar(kamar)
    print("Kamar berhasil ditambahkan!")

# Fungsi untuk menghapus kamar
def hapus_kamar(nomor_kamar):
    kamar = baca_kamar()
    kamar_baru = [k for k in kamar if k['nomor_kamar'] != nomor_kamar]
    if len(kamar_baru) < len(kamar):
        tulis_kamar(kamar_baru)
        print("Kamar berhasil dihapus.")
    else:
        print("Kamar tidak ditemukan.")

# Program utama
def main():
    initialize_csv()
    initialize_akun_csv()
    
    while True:
        print("\n=== Selamat Datang di Aplikasi Pemesanan Kamar Hotel kami! ===")
        print("1. Login")
        print("2. Buat Akun")
        print("3. Keluar")
        pilihan = input("Pilih menu: ")
        
        if pilihan == '1':
            login()
        elif pilihan == '2':
            buat_akun()
        elif pilihan == '3':
            print("Terima kasih telah menggunakan aplikasi ini.")
            break
        else:
            print("Pilihan tidak valid.")
          
# Main untuk menjalankan program
if __name__ == "__main__":
    main()